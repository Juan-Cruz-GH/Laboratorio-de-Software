# PacMan-Game-Java_Swing
[![output](https://github.com/naor2205/PacMan-Game-Java_Swing/blob/master/pacman.PNG)]
