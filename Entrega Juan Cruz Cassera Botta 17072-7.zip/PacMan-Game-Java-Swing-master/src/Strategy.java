public interface Strategy {
	void changeDirection(Ghost ghost, boolean mustChangeDirection);
}
